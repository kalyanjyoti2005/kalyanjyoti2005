import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertWaitlistSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // Waitlist API endpoint
  app.post('/api/waitlist', async (req, res) => {
    try {
      // Validate request body
      const validatedData = insertWaitlistSchema.parse(req.body);
      
      // Check if email already exists
      const existingEntry = await storage.getWaitlistEntryByEmail(validatedData.email);
      if (existingEntry) {
        return res.status(409).json({ 
          message: "This email is already on the waitlist." 
        });
      }
      
      // Create waitlist entry
      const entry = await storage.createWaitlistEntry(validatedData);
      
      // Return success
      return res.status(201).json({ 
        message: "Successfully joined the waitlist!",
        entry
      });
    } catch (error) {
      // Handle validation errors
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ 
          message: "Validation error", 
          errors: validationError.message 
        });
      }
      
      // Handle other errors
      console.error("Waitlist error:", error);
      return res.status(500).json({ 
        message: "An unexpected error occurred. Please try again." 
      });
    }
  });

  // Get waitlist count (for analytics/dashboard)
  app.get('/api/waitlist/count', async (req, res) => {
    try {
      const count = await storage.getWaitlistCount();
      return res.json({ count });
    } catch (error) {
      console.error("Error getting waitlist count:", error);
      return res.status(500).json({ 
        message: "An unexpected error occurred."
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
