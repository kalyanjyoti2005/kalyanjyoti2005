// Re-export useToast hook so components can import from here
export { useToast, toast } from "@/components/ui/use-toast";
