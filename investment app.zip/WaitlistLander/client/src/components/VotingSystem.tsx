import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ThumbsUp, ThumbsDown, MessageCircle, Users, Award, TrendingUp, GraduationCap, Tag, Star } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

type Idea = {
  id: string;
  title: string;
  description: string;
  university: string;
  category: string;
  creator: string;
  publicVotes: number;
  investorVotes: number;
  comments: number;
  isTrending?: boolean;
};

const sampleIdeas: Idea[] = [
  {
    id: '1',
    title: 'EcoTracker - Campus Sustainability App',
    description: 'A mobile app that tracks individual and collective sustainability efforts across campus, with leaderboards and rewards for sustainable behaviors.',
    university: 'Stanford University',
    category: 'Mobile App',
    creator: 'Eco Team Alpha',
    publicVotes: 145,
    investorVotes: 12,
    comments: 23,
    isTrending: true,
  },
  {
    id: '2',
    title: 'StudySync - Group Study Coordination Platform',
    description: 'A platform connecting students with similar study needs, providing scheduling, resource sharing, and AI-powered study material generation.',
    university: 'MIT',
    category: 'EdTech',
    creator: 'Study Buddies',
    publicVotes: 98,
    investorVotes: 8,
    comments: 15,
  },
  {
    id: '3',
    title: 'DormDeal - Student Marketplace for Used Items',
    description: 'A secure campus-specific marketplace for students to buy, sell, and trade textbooks, furniture, and more with built-in verification.',
    university: 'NYU',
    category: 'Marketplace',
    creator: 'NYU Entrepreneurs',
    publicVotes: 127,
    investorVotes: 5,
    comments: 31,
    isTrending: true,
  },
  {
    id: '4',
    title: 'MentorMatch - Alumni Mentorship Network',
    description: 'A platform connecting students with alumni mentors based on career interests, skills, and goals, with structured mentorship tracks.',
    university: 'UC Berkeley',
    category: 'Networking',
    creator: 'Berkeley Connect',
    publicVotes: 87,
    investorVotes: 14,
    comments: 19,
  }
];

const VotingSystem = () => {
  const [ideas, setIdeas] = useState<Idea[]>(sampleIdeas);
  const [activeFilter, setActiveFilter] = useState<'all' | 'trending'>('all');
  const [votedIdeas, setVotedIdeas] = useState<Set<string>>(new Set());
  
  const handleVote = (ideaId: string, isPublicVote: boolean) => {
    if (votedIdeas.has(ideaId)) return;
    
    setIdeas(ideas.map(idea => {
      if (idea.id === ideaId) {
        return {
          ...idea,
          publicVotes: isPublicVote ? idea.publicVotes + 1 : idea.publicVotes,
          investorVotes: !isPublicVote ? idea.investorVotes + 1 : idea.investorVotes
        };
      }
      return idea;
    }));
    
    setVotedIdeas(new Set(votedIdeas).add(ideaId));
  };
  
  const filteredIdeas = activeFilter === 'trending' 
    ? ideas.filter(idea => idea.isTrending) 
    : ideas;
  
  return (
    <section id="voting" className="py-20 px-4 md:px-6 lg:px-8 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-6xl mx-auto">
        <motion.div 
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Vote on Student Ideas</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-8">
            Discover and support innovative ideas from college students across the country. Your vote helps the best concepts get noticed by investors.
          </p>
          
          <div className="flex justify-center gap-4 mb-8">
            <Button 
              variant={activeFilter === 'all' ? 'default' : 'outline'} 
              onClick={() => setActiveFilter('all')}
              className="gap-2"
            >
              <Users size={16} />
              All Ideas
            </Button>
            <Button 
              variant={activeFilter === 'trending' ? 'default' : 'outline'} 
              onClick={() => setActiveFilter('trending')}
              className="gap-2"
            >
              <TrendingUp size={16} />
              Trending
            </Button>
          </div>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {filteredIdeas.map((idea, index) => (
            <motion.div 
              key={idea.id}
              className="bg-white rounded-xl shadow-md overflow-hidden border border-gray-100"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <div className="p-6">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h3 className="text-xl font-bold mb-1">{idea.title}</h3>
                    <p className="text-gray-500 text-sm">{idea.university} • {idea.category}</p>
                  </div>
                  {idea.isTrending && (
                    <Badge variant="default" className="bg-gradient-to-r from-orange-400 to-red-500 gap-1">
                      <TrendingUp size={12} />
                      Trending
                    </Badge>
                  )}
                </div>
                
                <p className="text-gray-700 mb-4 line-clamp-3">{idea.description}</p>
                
                <div className="flex flex-wrap items-center gap-4 mb-4">
                  <div className="flex items-center gap-1.5">
                    <Badge variant="outline" className="bg-blue-50 border-blue-200 text-blue-700 flex items-center gap-1">
                      <Users size={12} />
                      Team: {idea.creator}
                    </Badge>
                  </div>
                </div>
                
                <div className="flex flex-wrap items-center justify-between border-t border-gray-100 pt-4">
                  <div className="flex items-center gap-4">
                    <button 
                      onClick={() => handleVote(idea.id, true)}
                      disabled={votedIdeas.has(idea.id)}
                      className={cn(
                        "flex items-center gap-1.5 text-sm font-medium transition-colors",
                        votedIdeas.has(idea.id) 
                          ? "text-primary cursor-default" 
                          : "text-gray-500 hover:text-primary"
                      )}
                    >
                      <ThumbsUp size={16} className={votedIdeas.has(idea.id) ? "fill-primary" : ""} />
                      {idea.publicVotes}
                    </button>
                    
                    <div className="flex items-center gap-1.5 text-sm text-gray-500">
                      <Award size={16} className="text-yellow-500" />
                      {idea.investorVotes} Investor Votes
                    </div>
                    
                    <div className="flex items-center gap-1.5 text-sm text-gray-500">
                      <MessageCircle size={16} />
                      {idea.comments}
                    </div>
                  </div>
                  
                  <Button size="sm" variant="outline" className="text-xs">
                    View Details
                  </Button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
        
        <div className="text-center mt-10">
          <Button size="lg" variant="default">
            View All Ideas
          </Button>
        </div>
      </div>
    </section>
  );
};

export default VotingSystem;