import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { GraduationCap } from 'lucide-react';

const Header = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <header className="relative z-10 py-6 px-4 md:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <div className="h-10 w-10 rounded-lg bg-gradient-to-r from-primary to-primary/70 flex items-center justify-center shadow-md">
            <GraduationCap className="text-white h-5 w-5" />
          </div>
          <span className="ml-2 text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-primary/70">InvestConnect</span>
          <span className="ml-1 text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full">Campus</span>
        </div>
        <nav className="hidden md:flex space-x-8">
          <a href="#features" className="font-medium text-gray-600 hover:text-primary transition-colors">Features</a>
          <a href="#how-it-works" className="font-medium text-gray-600 hover:text-primary transition-colors">How It Works</a>
          <a href="#voting" className="font-medium text-gray-600 hover:text-primary transition-colors">Student Ideas</a>
          <a href="#faq" className="font-medium text-gray-600 hover:text-primary transition-colors">FAQs</a>
        </nav>
        <div className="hidden md:block">
          <Button variant="outline" className="mr-2">Login</Button>
          <a href="#waitlist">
            <Button>Get Priority Access</Button>
          </a>
        </div>
        <button 
          onClick={toggleMobileMenu}
          className="md:hidden focus:outline-none" 
          aria-label="Open mobile menu"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>
      
      {/* Mobile menu */}
      <div className={`md:hidden absolute top-20 left-0 right-0 bg-white shadow-lg rounded-lg m-4 p-4 transition-opacity duration-200 ${mobileMenuOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
        <nav className="flex flex-col space-y-4">
          <a href="#features" className="font-medium text-gray-600 hover:text-primary transition-colors py-2">Features</a>
          <a href="#how-it-works" className="font-medium text-gray-600 hover:text-primary transition-colors py-2">How It Works</a>
          <a href="#voting" className="font-medium text-gray-600 hover:text-primary transition-colors py-2">Student Ideas</a>
          <a href="#faq" className="font-medium text-gray-600 hover:text-primary transition-colors py-2">FAQs</a>
          <div className="pt-2 flex flex-col space-y-2">
            <Button variant="outline" className="w-full">Login</Button>
            <a href="#waitlist" className="w-full">
              <Button className="w-full">Get Priority Access</Button>
            </a>
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Header;
