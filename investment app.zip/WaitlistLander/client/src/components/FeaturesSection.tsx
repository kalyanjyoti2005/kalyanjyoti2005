import React from 'react';
import { motion } from 'framer-motion';
import { 
  ShieldCheck, Shield, FileText, BadgeCheck, Lock, BarChart4Icon,
  ThumbsUp, TrendingUp, GraduationCap, Award, Briefcase, Users
} from 'lucide-react';

const features = [
  {
    icon: <GraduationCap className="h-6 w-6 text-primary" />,
    title: "Student-Centric Idea Submission",
    description: "Simple forms designed for college students to submit ideas as individuals or teams, with special categories for hackathon projects.",
    color: "bg-primary/10",
    delay: 0.1,
  },
  {
    icon: <BadgeCheck className="h-6 w-6 text-blue-600" />,
    title: "Student-Investor Matching",
    description: "Connect with investors specifically interested in student-led startups, with access to grants and university funding opportunities.",
    color: "bg-blue-100",
    delay: 0.2,
  },
  {
    icon: <Users className="h-6 w-6 text-green-600" />,
    title: "Mentorship & Learning",
    description: "Get personalized guidance from industry experts and alumni who provide feedback and support for student entrepreneurs.",
    color: "bg-green-100",
    delay: 0.3,
  },
  {
    icon: <ThumbsUp className="h-6 w-6 text-indigo-600" />,
    title: "Peer Voting & Feedback",
    description: "Vote on promising campus ideas and leave detailed peer feedback to help fellow students improve their concepts.",
    color: "bg-indigo-100",
    delay: 0.4,
  },
  {
    icon: <Award className="h-6 w-6 text-yellow-600" />,
    title: "Hackathons & Competitions",
    description: "Join exclusive student hackathons and startup challenges with certificates, prizes, and funding opportunities for winners.",
    color: "bg-yellow-100",
    delay: 0.5,
  },
  {
    icon: <Briefcase className="h-6 w-6 text-pink-600" />,
    title: "Internship Opportunities",
    description: "Access internship postings from startups seeking student talent and build your career through entrepreneurial experiences.",
    color: "bg-pink-100",
    delay: 0.6,
  },
  {
    icon: <FileText className="h-6 w-6 text-purple-600" />,
    title: "NDA-Protected Submissions",
    description: "All student ideas are protected by our legally binding NDA system before any investor can view them, ensuring your intellectual property stays secure.",
    color: "bg-purple-100",
    delay: 0.7,
  },
  {
    icon: <TrendingUp className="h-6 w-6 text-red-600" />,
    title: "Campus Leaderboards",
    description: "See which universities and student teams are trending with our real-time leaderboards showcasing the top-voted ideas across campuses.",
    color: "bg-red-100",
    delay: 0.8,
  },
];

const FeaturesSection = () => {
  return (
    <section id="features" className="py-20 px-4 md:px-6 lg:px-8 bg-white">
      <div className="max-w-7xl mx-auto">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Student Entrepreneur Features</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Our platform was designed with college students in mind, providing everything you need to transform your innovative ideas into reality.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              className="bg-gradient-to-br from-gray-50/80 to-gray-50/40 backdrop-blur-sm rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow duration-300"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: feature.delay }}
            >
              <div className={`w-12 h-12 rounded-lg ${feature.color} flex items-center justify-center mb-4`}>
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
