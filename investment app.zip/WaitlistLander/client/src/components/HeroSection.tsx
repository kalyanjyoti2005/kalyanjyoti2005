import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Shield, TrendingUp, GraduationCap, Users } from 'lucide-react';

const HeroSection = () => {
  return (
    <section className="relative pt-20 pb-16 overflow-hidden px-4 md:px-6 lg:px-8 bg-gradient-to-br from-primary/5 via-primary/10 to-background">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold leading-tight tracking-tight text-gray-900 mb-6">
              Turn Your Campus Ideas into <span className="bg-clip-text text-transparent bg-gradient-to-r from-primary to-primary/70">Reality</span>
            </h1>
            <p className="text-lg md:text-xl text-gray-600 mb-6 max-w-lg">
              A student-focused platform for college entrepreneurs to securely share ideas, get mentorship, and connect with investors ready to fund the next generation of innovators.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 mb-10">
              <div className="flex items-center text-sm text-gray-700">
                <GraduationCap className="h-5 w-5 mr-2 text-primary" />
                <span>Student-Centric Platform</span>
              </div>
              <div className="flex items-center text-sm text-gray-700">
                <Users className="h-5 w-5 mr-2 text-primary" />
                <span>Mentorship & Support</span>
              </div>
            </div>
            <div className="space-x-4">
              <Button size="lg" className="shadow-lg">
                Get Early Access
              </Button>
              <Button size="lg" variant="outline">
                Learn More
              </Button>
            </div>
          </motion.div>
          
          <motion.div 
            className="md:pl-10"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <div className="relative rounded-xl overflow-hidden shadow-2xl">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-primary/10 backdrop-blur-sm"></div>
              <img 
                src="https://images.unsplash.com/photo-1523240795612-9a054b0db644?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80" 
                alt="College students collaborating" 
                className="w-full h-auto relative z-10 rounded-xl" 
                width="600" 
                height="400"
              />
            </div>
          </motion.div>
        </div>

        {/* Trust Indicators */}
        <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          {[
            { value: "150+", label: "University Partners", delay: 0.1 },
            { value: "300+", label: "Student Startups", delay: 0.2 },
            { value: "75+", label: "Active Mentors", delay: 0.3 },
            { value: "25+", label: "Student Hackathons", delay: 0.4 }
          ].map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: stat.delay }}
              className="bg-white/50 backdrop-blur-sm p-6 rounded-lg shadow-md"
            >
              <p className="text-3xl md:text-4xl font-bold text-primary">{stat.value}</p>
              <p className="text-gray-600 mt-2">{stat.label}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
