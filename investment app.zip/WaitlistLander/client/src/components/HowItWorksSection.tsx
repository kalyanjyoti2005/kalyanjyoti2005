import React from 'react';
import { motion } from 'framer-motion';
import { 
  UserCheck, FilePlus, Users, TrendingUp, ThumbsUp, 
  GraduationCap, Award, Briefcase, MessageCircle 
} from 'lucide-react';

const steps = [
  {
    number: 1,
    icon: <GraduationCap className="h-6 w-6 text-white" />,
    title: "Register With .edu Email",
    description: "Sign up with your university email to verify your student status and gain access to exclusive opportunities.",
    delay: 0.1,
  },
  {
    number: 2,
    icon: <FilePlus className="h-6 w-6 text-white" />,
    title: "Submit Your Campus Idea",
    description: "Share your innovative concept through our student-friendly submission form with NDA protection for your intellectual property.",
    delay: 0.2,
  },
  {
    number: 3,
    icon: <MessageCircle className="h-6 w-6 text-white" />,
    title: "Get Peer Feedback & Votes",
    description: "Fellow students and mentors provide constructive feedback and vote on your concept to help refine and improve it.",
    delay: 0.3,
  },
  {
    number: 4,
    icon: <Award className="h-6 w-6 text-white" />,
    title: "Join Competitions & Workshops",
    description: "Participate in hackathons, pitch competitions, and expert-led workshops to develop your idea and build your network.",
    delay: 0.4,
  },
  {
    number: 5,
    icon: <Briefcase className="h-6 w-6 text-white" />,
    title: "Connect With Funding & Mentors",
    description: "Top-rated ideas gain exposure to investors, grants, and dedicated mentorship to help launch your startup journey.",
    delay: 0.5,
  },
];

const HowItWorksSection = () => {
  return (
    <section id="how-it-works" className="py-20 px-4 md:px-6 lg:px-8 bg-gray-50">
      <div className="max-w-7xl mx-auto">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Your Path to Campus Innovation</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Our student-focused platform makes it easy to bring your ideas to life and connect with resources specifically designed for college entrepreneurs.
          </p>
        </motion.div>

        <div className="relative">
          {/* Connecting line */}
          <div className="hidden md:block absolute top-1/2 left-0 right-0 h-0.5 bg-gradient-to-r from-primary to-secondary transform -translate-y-1/2 z-0"></div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6 relative z-10">
            {steps.map((step, index) => (
              <motion.div 
                key={index}
                className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: step.delay }}
              >
                <div className="w-14 h-14 rounded-full bg-primary text-white font-bold flex items-center justify-center mb-6 mx-auto">
                  {step.icon ? step.icon : step.number}
                </div>
                <h3 className="text-xl font-bold mb-3 text-center">{step.title}</h3>
                <p className="text-gray-600 text-center">{step.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorksSection;
