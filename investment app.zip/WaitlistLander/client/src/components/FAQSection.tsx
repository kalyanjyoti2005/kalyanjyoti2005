import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    question: "Do I need to be enrolled in a university to use InvestConnect Campus?",
    answer: "Yes, InvestConnect Campus is specifically designed for active college and university students. You'll need a valid .edu email address to register, which helps us verify your student status and maintain the integrity of our campus-focused community."
  },
  {
    question: "How does the peer voting and feedback system help my idea?",
    answer: "Our platform features an innovative voting system where both student peers and verified mentors can upvote promising ideas. The peer feedback system allows you to collect valuable insights from fellow students across various disciplines, helping refine your concept before presenting to investors. Top-voted ideas gain visibility on leaderboards and may qualify for special funding opportunities."
  },
  {
    question: "What types of resources are available for student entrepreneurs?",
    answer: "InvestConnect Campus offers a comprehensive suite of resources including mentorship from industry professionals and successful alumni, educational workshops on startup fundamentals, networking events with investors interested in student ventures, and access to university innovation grants and competitions. We also provide guidance on legal aspects of business formation specifically for student entrepreneurs."
  },
  {
    question: "Can I list my hackathon or class project on the platform?",
    answer: "Absolutely! We welcome projects from hackathons, class assignments, senior capstones, and research initiatives. We have special categories designed for these types of projects to help them get appropriate feedback and potentially connect with resources for further development. You can indicate the project origin when submitting your idea."
  },
  {
    question: "How does InvestConnect Campus help with university funding and grants?",
    answer: "We maintain partnerships with university innovation offices and departmental grant programs across the country. Through our platform, you can discover available funding opportunities specific to your institution, field of study, or project type. Our team also provides guidance on application processes and connects promising ventures with university-affiliated angel investors."
  },
  {
    question: "Do I maintain ownership of my idea when using the platform?",
    answer: "Yes, you retain 100% ownership of your intellectual property. We use secure NDA protection before investors can view detailed information about your concept. Our platform is designed to facilitate connections and provide resources, not to take equity or ownership stakes in your ideas. Any investment arrangements are made directly between you and interested parties."
  },
  {
    question: "When will InvestConnect Campus launch at my university?",
    answer: "We're rolling out to universities across the country throughout 2025, starting with major innovation hubs. Waitlist members will receive early access, with priority given to students from partner universities. You can indicate your university when joining the waitlist to help us prioritize our launch schedule."
  }
];

const FAQSection = () => {
  return (
    <section id="faq" className="py-20 px-4 md:px-6 lg:px-8 bg-white">
      <div className="max-w-4xl mx-auto">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Student FAQs</h2>
          <p className="text-xl text-gray-600">Find answers to common questions about how InvestConnect Campus helps student entrepreneurs succeed.</p>
        </motion.div>

        <motion.div
          className="space-y-4"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`} className="border border-gray-200 rounded-lg overflow-hidden mb-4">
                <AccordionTrigger className="px-6 py-4 text-lg font-semibold text-left hover:no-underline">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-4 text-gray-600">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </motion.div>
      </div>
    </section>
  );
};

export default FAQSection;
